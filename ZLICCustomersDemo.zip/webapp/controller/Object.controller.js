/*global location*/
sap.ui.define([
	"zliccustomersdemo/ZLICCustomersDemo/controller/BaseController",
	"sap/ui/model/json/JSONModel",
	"sap/ui/core/routing/History",
	"zliccustomersdemo/ZLICCustomersDemo/model/formatter"
], function(
	BaseController,
	JSONModel,
	History,
	formatter
) {
	"use strict";

	return BaseController.extend("zliccustomersdemo.ZLICCustomersDemo.controller.Object", {

		formatter: formatter,
		onInit: function() {
			this.oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			this.oRouter.getRoute("object").attachPatternMatched(this.username, this);
			var jsonmodel = this.getOwnerComponent().getModel("liccustomers");
			this.getView().setModel(jsonmodel, "liccust");
		}, // end of onInit
		username: function(oevent) {
			//	var username = oevent.getParameter("arguments").username;
			//	this.byId("page1").setTitle("Welcome:" + username);
		}, // end of username
		_topage3: function(oevent) {
			this.oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			this.oRouter.navTo("detailpage", {
				from: "object",
				to: "detailpage",
				ID: oevent.getSource().getBindingContext("liccust").getProperty("ID"),
				customername: oevent.getSource().getBindingContext("liccust").getProperty("customername"),
				totalpremamntandterm: oevent.getSource().getBindingContext("liccust").getProperty("totalpremamntandterm"),
				premiumbegda: oevent.getSource().getBindingContext("liccust").getProperty("premiumbegda"),
				emiamnttobepaidonduedate: oevent.getSource().getBindingContext("liccust").getProperty("emiamnttobepaidonduedate"),
				amntpaidtillnow: oevent.getSource().getBindingContext("liccust").getProperty("amntpaidtillnow"),
				pendingamnttobepaid: oevent.getSource().getBindingContext("liccust").getProperty("pendingamnttobepaid"),
				monthlypay: oevent.getSource().getBindingContext("liccust").getProperty("monthlypay"),
				yearlypay: oevent.getSource().getBindingContext("liccust").getProperty("yearlypay"),
				premiumenda: oevent.getSource().getBindingContext("liccust").getProperty("premiumenda")

			}, true);
		}, // end of _topage3
		onAdd: function(oEvent) {
			var oItem = new sap.m.ColumnListItem({
				cells: [
					new sap.m.Input({
						width: "auto"
					}),
					new sap.m.Input({
						width: "auto"
					}),
					new sap.m.Button({
						text: "Delete",
						press: [this.remove, this]
					})
				]
			});

			var oTable = this.getView().byId("liccustomers");
			oTable.addItem(oItem);

		},
		deleteRow: function(oEvent) {
			var oTable = this.getView().byId("liccustomers");
			oTable.removeItem(oEvent.getParameter("listItem"));
		},
		remove: function(oEvent) {
			var oTable = this.getView().byId("liccustomers");
			oTable.removeItem(oEvent.getSource().getParent());
		},
		_logout: function(oevent) {
			this.oRouter.navTo("worklist", {}, true);
		}, // end of _logout
		/* =========================================================== */
		/* lifecycle methods                                           */
		/* =========================================================== */

		/**
		 * Called when the worklist controller is instantiated.
		 * @public
		 */
		_onInit: function() {
			// Model used to manipulate control states. The chosen values make sure,
			// detail page is busy indication immediately so there is no break in
			// between the busy indication for loading the view's meta data
			var iOriginalBusyDelay,
				oViewModel = new JSONModel({
					busy: true,
					delay: 0
				});

			this.getRouter().getRoute("object").attachPatternMatched(this._onObjectMatched, this);

			// Store original busy indicator delay, so it can be restored later on
			iOriginalBusyDelay = this.getView().getBusyIndicatorDelay();
			this.setModel(oViewModel, "objectView");
			this.getOwnerComponent().getModel().metadataLoaded().then(function() {
				// Restore original busy indicator delay for the object view
				oViewModel.setProperty("/delay", iOriginalBusyDelay);
			});
		},

		/* =========================================================== */
		/* event handlers                                              */
		/* =========================================================== */

		/**
		 * Event handler when the share in JAM button has been clicked
		 * @public
		 */
		onShareInJamPress: function() {
			var oViewModel = this.getModel("objectView"),
				oShareDialog = sap.ui.getCore().createComponent({
					name: "sap.collaboration.components.fiori.sharing.dialog",
					settings: {
						object: {
							id: location.href,
							share: oViewModel.getProperty("/shareOnJamTitle")
						}
					}
				});
			oShareDialog.open();
		},

		/* =========================================================== */
		/* internal methods                                            */
		/* =========================================================== */

		/**
		 * Binds the view to the object path.
		 * @function
		 * @param {sap.ui.base.Event} oEvent pattern match event in route 'object'
		 * @private
		 */
		_onObjectMatched: function(oEvent) {
			var sObjectId = oEvent.getParameter("arguments").objectId;
			this.getModel().metadataLoaded().then(function() {
				var sObjectPath = this.getModel().createKey("ProductSet", {
					ProductID: sObjectId
				});
				this._bindView("/" + sObjectPath);
			}.bind(this));
		},

		/**
		 * Binds the view to the object path.
		 * @function
		 * @param {string} sObjectPath path to the object to be bound
		 * @private
		 */
		_bindView: function(sObjectPath) {
			var oViewModel = this.getModel("objectView"),
				oDataModel = this.getModel();

			this.getView().bindElement({
				path: sObjectPath,
				events: {
					change: this._onBindingChange.bind(this),
					dataRequested: function() {
						oDataModel.metadataLoaded().then(function() {
							// Busy indicator on view should only be set if metadata is loaded,
							// otherwise there may be two busy indications next to each other on the
							// screen. This happens because route matched handler already calls '_bindView'
							// while metadata is loaded.
							oViewModel.setProperty("/busy", true);
						});
					},
					dataReceived: function() {
						oViewModel.setProperty("/busy", false);
					}
				}
			});
		},

		_onBindingChange: function() {
			var oView = this.getView(),
				oViewModel = this.getModel("objectView"),
				oElementBinding = oView.getElementBinding();

			// No data for the binding
			if (!oElementBinding.getBoundContext()) {
				this.getRouter().getTargets().display("objectNotFound");
				return;
			}

			var oResourceBundle = this.getResourceBundle(),
				oObject = oView.getBindingContext().getObject(),
				sObjectId = oObject.ProductID,
				sObjectName = oObject.Category;

			oViewModel.setProperty("/busy", false);
			// Add the object page to the flp routing history
			this.addHistoryEntry({
				title: this.getResourceBundle().getText("objectTitle") + " - " + sObjectName,
				icon: "sap-icon://enter-more",
				intent: "#ZLICCustomersDemo-display&/ProductSet/" + sObjectId
			});

			oViewModel.setProperty("/saveAsTileTitle", oResourceBundle.getText("saveAsTileTitle", [sObjectName]));
			oViewModel.setProperty("/shareOnJamTitle", sObjectName);
			oViewModel.setProperty("/shareSendEmailSubject",
				oResourceBundle.getText("shareSendEmailObjectSubject", [sObjectId]));
			oViewModel.setProperty("/shareSendEmailMessage",
				oResourceBundle.getText("shareSendEmailObjectMessage", [sObjectName, sObjectId, location.href]));
		}

	});

});