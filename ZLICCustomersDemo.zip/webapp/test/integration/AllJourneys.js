/*global QUnit*/

jQuery.sap.require("sap.ui.qunit.qunit-css");
jQuery.sap.require("sap.ui.thirdparty.qunit");
jQuery.sap.require("sap.ui.qunit.qunit-junit");
QUnit.config.autostart = false;

sap.ui.require([
	"sap/ui/test/Opa5",
	"zliccustomersdemo/ZLICCustomersDemo/test/integration/pages/Common",
	"sap/ui/test/opaQunit",
	"zliccustomersdemo/ZLICCustomersDemo/test/integration/pages/Worklist",
	"zliccustomersdemo/ZLICCustomersDemo/test/integration/pages/Object",
	"zliccustomersdemo/ZLICCustomersDemo/test/integration/pages/NotFound",
	"zliccustomersdemo/ZLICCustomersDemo/test/integration/pages/Browser",
	"zliccustomersdemo/ZLICCustomersDemo/test/integration/pages/App"
], function (Opa5, Common) {
	"use strict";
	Opa5.extendConfig({
		arrangements: new Common(),
		viewNamespace: "zliccustomersdemo.ZLICCustomersDemo.view."
	});

	sap.ui.require([
		"zliccustomersdemo/ZLICCustomersDemo/test/integration/WorklistJourney",
		"zliccustomersdemo/ZLICCustomersDemo/test/integration/ObjectJourney",
		"zliccustomersdemo/ZLICCustomersDemo/test/integration/NavigationJourney",
		"zliccustomersdemo/ZLICCustomersDemo/test/integration/NotFoundJourney",
		"zliccustomersdemo/ZLICCustomersDemo/test/integration/FLPIntegrationJourney"
	], function () {
		QUnit.start();
	});
});