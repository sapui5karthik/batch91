sap.ui.define(["sap/ui/core/mvc/Controller",
	"sap/m/MessageBox",
	"./D0_1461153265067",
	"./D1_1461153528948",
	"./utilities",
	"sap/ui/core/routing/History",
	"ZCER_MANAGER/model/formatter",
	"sap/ui/model/odata/ODataModel",
	"sap/ui/model/json/JSONModel",
	"sap/ui/model/Filter",
	"sap/m/MessageToast",
	"sap/ui/model/FilterOperator",
	"sap/ui/core/routing/HashChanger"
], function(BaseController, MessageBox, D0_1461153265067, D1_1461153528948, Utilities, History, formatter, ODataModel, JSONModel, Filter,
	MessageToast, FilterOperator, HashChanger) {
	"use strict";

	return BaseController.extend("ZCER_MANAGER.controller.1460972029486_S1", {
		formatter: formatter,
		/*	handleRouteMatched: function(oEvent) {
				var sAppId = "App5f7cfa4ad5dbc32eadbb26ae";

				var oParams = {};

				if (oEvent.mParameters.data.context) {
					this.sContext = oEvent.mParameters.data.context;

				} else {
					if (this.getOwnerComponent().getComponentData()) {
						var patternConvert = function(oParam) {
							if (Object.keys(oParam).length !== 0) {
								for (var prop in oParam) {
									if (prop !== "sourcePrototype" && prop.includes("Set")) {
										return prop + "(" + oParam[prop][0] + ")";
									}
								}
							}
						};

						this.sContext = patternConvert(this.getOwnerComponent().getComponentData().startupParameters);

					}
				}

				var oPath;

				if (this.sContext) {
					oPath = {
						path: "/" + this.sContext,
						parameters: oParams
					};
					this.getView().bindObject(oPath);
				}

			},*/
		_onButtonPress: function(oEvent) {

			var sDialogName = "D0_1461153265067";
			this.mDialogs = this.mDialogs || {};
			var oDialog = this.mDialogs[sDialogName];
			if (!oDialog) {
				oDialog = new D0_1461153265067(this.getView());
				this.mDialogs[sDialogName] = oDialog;

				// For navigation.
				oDialog.setRouter(this.oRouter);
			}

			var context = oEvent.getSource().getBindingContext();
			oDialog._oControl.setBindingContext(context);

			oDialog.open();

		},
		_onButtonPress1: function(oEvent) {

			var sDialogName = "D1_1461153528948";
			this.mDialogs = this.mDialogs || {};
			var oDialog = this.mDialogs[sDialogName];
			if (!oDialog) {
				oDialog = new D1_1461153528948(this.getView());
				this.mDialogs[sDialogName] = oDialog;

				// For navigation.
				oDialog.setRouter(this.oRouter);
			}

			var context = oEvent.getSource().getBindingContext();
			oDialog._oControl.setBindingContext(context);

			oDialog.open();

		},
		_handleZCerIdMatched: function(oevent) {

			this.ZCerId = oevent.getParameter("arguments").ZCerId;

			var details_url = "/sap/opu/odata/sap/ZCER_MSS_ORJECT_SRV/";
			var details_odatamodel = new ODataModel(details_url);
			var details_jsonmodel = new JSONModel();
			var esetzcerid = "CER_MASTERSet('" + this.ZCerId + "')";
			sap.ui.core.BusyIndicator.show(0);
			details_odatamodel.read(esetzcerid, {

				success: function(odata, response) {
					sap.ui.core.BusyIndicator.hide();
					this.zcertstatus = odata.ZCerStatus;
					details_jsonmodel.setData(odata);
					this.getView().setModel(details_jsonmodel, "objhd");

					//this.getView().byId("idcompcode").setModel(details_jsonmodel,"h1");
				}.bind(this),
				error: function(msg) {
					sap.ui.core.BusyIndicator.hide();
					MessageToast.show("Failed:2000:" + msg);

				}
			});
		}, // end of _handleZCerIdMatched
		_identifyLoggedinUser: function(user) {
			this.loggedinuser = user;

			// check if logged in user is Finance Approver

			var data_loggeduser = "/sap/opu/odata/sap/ZCER_PROJECT_SRV/";

			var datamodel_loggedinuser = new ODataModel(data_loggeduser);
			var finteam = new Filter("DropDown", FilterOperator.EQ, "Z_CER_FIN_TEAM");

			datamodel_loggedinuser.read("/CER_DROP_DOWNSet", {
				filters: [finteam],
				success: function(odata, response) {
					var a = [];
					for (var i = 0; i < odata.results.length; ++i) {

						if (this.loggedinuser === odata.results[i].DispValue) {
							a.push(this.loggedinuser);
						}
					}

					if (a.length !== 0) {
						//	MessageToast.show("Finance Approver");
						this.user = "FA";
						this.byId("butapp1").setVisible(true);
						this.byId("butapp2").setVisible(true);
					}

				}.bind(this),
				error: function(msg) {
					MessageToast.show("Failed:0001" + msg);
				}
			});

		}, // end of _identifyLoggedinUser
		_onApproveButtonPress: function(oevent) {
			if (!this.dpa) {
				this.dpa = sap.ui.xmlfragment(this.getView().getId(), "ZCER_MANAGER.fragments.DetailsPageApprove", this);
				this.getView().addDependent(this.dpa);
			}
			this.dpa.open();

		}, // end of _onApproveButtonPress

		_onApprovalCompleted: function() {

			// finance approved 4
			// approver1 approved 6
			// approver2 approved 8
			if (this.user === "FA" && this.zcertstatus === "2") {

				//MessageToast.show("FA");
					var details_url = "/sap/opu/odata/sap/ZCER_MSS_ORJECT_SRV/";
					var details_odatamodel = new ODataModel(details_url);

					var esetzcerid1 = "CER_MASTERSet('" + this.ZCerId + "')";
					sap.ui.core.BusyIndicator.show(0);
					details_odatamodel.read(esetzcerid1, {

						success: function(odata, response) {
							sap.ui.core.BusyIndicator.hide();
							
							//this.byId("app1name").setText(odata.ZApprover1Name);
	var approvejsonmodel = this.getView().getModel("objhd");
				var approvalentry = {
					ZCerId: this.ZCerId,
					ZCerStatus: "4",
				ZApprover1: odata.ZApprover1,
					ZApprover1Name: odata.ZApprover1Name,
					ZApprover2: odata.ZApprover2,
					ZApprover2Name: odata.ZApprover2Name,
					ZAssetClass: approvejsonmodel.oData.ZAssetClass,
					ZBudgeted: approvejsonmodel.oData.ZBudgeted,
					ZBudgetedAmount: approvejsonmodel.oData.ZBudgetedAmount,
					ZBusinessJustification: approvejsonmodel.oData.ZBusinessJustification,
					ZCompanyCode: approvejsonmodel.oData.ZCompanyCode,
					ZCostCenter: approvejsonmodel.oData.ZCostCenter,
					ZCurrency: approvejsonmodel.oData.ZCurrency,
					ZDateSubmitted: approvejsonmodel.oData.ZDateSubmitted,
					ZEnvironmentConsidDesc: approvejsonmodel.oData.ZEnvironmentConsidDesc,
					ZEnvironmentConsideration: approvejsonmodel.oData.ZEnvironmentConsideration,
					ZEstimatedFinishDate: new Date(this.byId("idfinishdate").getText()).toJSON().split("Z")[0],
					ZEstimatedStartDate: new Date(this.byId("idstartdate").getText()).toJSON().split("Z")[0],
					ZInternalResourcesDetails1: approvejsonmodel.oData.ZInternalResourcesDetails1,
					ZInternalResourcesDetails2: approvejsonmodel.oData.ZInternalResourcesDetails2,
					ZInternalResourcesDetails3: approvejsonmodel.oData.ZInternalResourcesDetails3,
					ZInternalResourcesDetails4: approvejsonmodel.oData.ZInternalResourcesDetails4,
					ZInternalResourcesGroup1: approvejsonmodel.oData.ZInternalResourcesGroup1,
					ZInternalResourcesGroup2: approvejsonmodel.oData.ZInternalResourcesGroup2,
					ZInternalResourcesGroup3: approvejsonmodel.oData.ZInternalResourcesGroup3,
					ZInternalResourcesGroup4: approvejsonmodel.oData.ZInternalResourcesGroup4,
					ZInternalResourcesHours1: approvejsonmodel.oData.ZInternalResourcesHours1,
					ZInternalResourcesHours2: approvejsonmodel.oData.ZInternalResourcesHours2,
					ZInternalResourcesHours3: approvejsonmodel.oData.ZInternalResourcesHours3,
					ZInternalResourcesHours4: approvejsonmodel.oData.ZInternalResourcesHours4,
					ZManufacturingEquipment: approvejsonmodel.oData.ZManufacturingEquipment,
					ZNonCapexDescription1: approvejsonmodel.oData.ZNonCapexDescription1,
					ZNonCapexDescription1Txt: approvejsonmodel.oData.ZNonCapexDescription1Txt,
					ZNonCapexDescription2: approvejsonmodel.oData.ZNonCapexDescription2,
					ZNonCapexDescription2Txt: approvejsonmodel.oData.ZNonCapexDescription2Txt,
					ZNonCapexDescription3: approvejsonmodel.oData.ZNonCapexDescription3,
					ZNonCapexDescription4: approvejsonmodel.oData.ZNonCapexDescription4,
					ZNonCapexDetails1: approvejsonmodel.oData.ZNonCapexDetails1,
					ZNonCapexDetails2: approvejsonmodel.oData.ZNonCapexDetails2,
					ZNonCapexDetails3: approvejsonmodel.oData.ZNonCapexDetails3,
					ZNonCapexDetails4: approvejsonmodel.oData.ZNonCapexDetails4,
					ZNonCapexExpense1: approvejsonmodel.oData.ZNonCapexExpense1,
					ZNonCapexExpense2: approvejsonmodel.oData.ZNonCapexExpense2,
					ZNonCapexExpense3: approvejsonmodel.oData.ZNonCapexExpense3,
					ZNonCapexExpense4: approvejsonmodel.oData.ZNonCapexExpense4,
					ZProjectDescription: approvejsonmodel.oData.ZProjectDescription,
					ZProjectId: approvejsonmodel.oData.ZProjectId,
					ZReplacingAsset: approvejsonmodel.oData.ZReplacingAsset,
					ZReplacingAssetCerNumber: approvejsonmodel.oData.ZReplacingAssetCerNumber,
					ZReplacingAssetCostCenter: approvejsonmodel.oData.ZReplacingAssetCostCenter,
					ZReplacingAssetDescription: approvejsonmodel.oData.ZReplacingAssetDescription,
					ZReplacingAssetSerialNumb: approvejsonmodel.oData.ZReplacingAssetSerialNumb,
					ZRequestor: approvejsonmodel.oData.ZRequestor,
					ZRequestorId: approvejsonmodel.oData.ZRequestorId,
					ZSoftware: approvejsonmodel.oData.ZSoftware,
					ZUsefulLifeYear: approvejsonmodel.oData.ZUsefulLifeYear

				};
					var approveurl = "/sap/opu/odata/sap/ZCER_MSS_ORJECT_SRV/";
				var approveodatamodel = new ODataModel(approveurl);

				var esetzcerid = "CER_MASTERSet('" + this.ZCerId + "')";

				sap.ui.core.BusyIndicator.show(0);
				approveodatamodel.update(esetzcerid, approvalentry, {

					success: function(odata1, response) {
						sap.ui.core.BusyIndicator.hide();
						this.dpa.close();
					//	MessageToast.show("Finance Approved");
						master._identifyLoggedinUser(master.loggedinuser);
						HashChanger.getInstance().replaceHash("");
					}.bind(this),
					error: function(msg) {
						sap.ui.core.BusyIndicator.hide();

						MessageToast.show("Failed:2002:" + msg);

					}
				});
						}.bind(this),
						error: function(msg) {
							sap.ui.core.BusyIndicator.hide();
							MessageToast.show("Failed:2012:" + msg);

						}
					});
					
			
			

			} else {
				if (this.zcertstatus === "4") {

					var a1approvejsonmodel = this.getView().getModel("objhd");

					var a1approvalentry = {
						ZCerId: this.ZCerId,
						ZCerStatus: "6",
						ZApprover1: a1approvejsonmodel.oData.ZApprover1,
						ZApprover1Name: a1approvejsonmodel.oData.ZApprover1Name,
						ZApprover2: a1approvejsonmodel.oData.ZApprover2,
						ZApprover2Name: a1approvejsonmodel.oData.ZApprover2Name,
						ZAssetClass: a1approvejsonmodel.oData.ZAssetClass,
						ZBudgeted: a1approvejsonmodel.oData.ZBudgeted,
						ZBudgetedAmount: a1approvejsonmodel.oData.ZBudgetedAmount,
						ZBusinessJustification: a1approvejsonmodel.oData.ZBusinessJustification,
						ZCompanyCode: a1approvejsonmodel.oData.ZCompanyCode,
						ZCostCenter: a1approvejsonmodel.oData.ZCostCenter,
						ZCurrency: a1approvejsonmodel.oData.ZCurrency,
						ZDateSubmitted: a1approvejsonmodel.oData.ZDateSubmitted,
						ZEnvironmentConsidDesc: a1approvejsonmodel.oData.ZEnvironmentConsidDesc,
						ZEnvironmentConsideration: a1approvejsonmodel.oData.ZEnvironmentConsideration,
						ZEstimatedFinishDate: new Date(this.byId("idfinishdate").getText()).toJSON().split("Z")[0],
						ZEstimatedStartDate: new Date(this.byId("idstartdate").getText()).toJSON().split("Z")[0],
						ZInternalResourcesDetails1: a1approvejsonmodel.oData.ZInternalResourcesDetails1,
						ZInternalResourcesDetails2: a1approvejsonmodel.oData.ZInternalResourcesDetails2,
						ZInternalResourcesDetails3: a1approvejsonmodel.oData.ZInternalResourcesDetails3,
						ZInternalResourcesDetails4: a1approvejsonmodel.oData.ZInternalResourcesDetails4,
						ZInternalResourcesGroup1: a1approvejsonmodel.oData.ZInternalResourcesGroup1,
						ZInternalResourcesGroup2: a1approvejsonmodel.oData.ZInternalResourcesGroup2,
						ZInternalResourcesGroup3: a1approvejsonmodel.oData.ZInternalResourcesGroup3,
						ZInternalResourcesGroup4: a1approvejsonmodel.oData.ZInternalResourcesGroup4,
						ZInternalResourcesHours1: a1approvejsonmodel.oData.ZInternalResourcesHours1,
						ZInternalResourcesHours2: a1approvejsonmodel.oData.ZInternalResourcesHours2,
						ZInternalResourcesHours3: a1approvejsonmodel.oData.ZInternalResourcesHours3,
						ZInternalResourcesHours4: a1approvejsonmodel.oData.ZInternalResourcesHours4,
						ZManufacturingEquipment: a1approvejsonmodel.oData.ZManufacturingEquipment,
						ZNonCapexDescription1: a1approvejsonmodel.oData.ZNonCapexDescription1,
						ZNonCapexDescription1Txt: a1approvejsonmodel.oData.ZNonCapexDescription1Txt,
						ZNonCapexDescription2: a1approvejsonmodel.oData.ZNonCapexDescription2,
						ZNonCapexDescription2Txt: a1approvejsonmodel.oData.ZNonCapexDescription2Txt,
						ZNonCapexDescription3: a1approvejsonmodel.oData.ZNonCapexDescription3,
						ZNonCapexDescription4: a1approvejsonmodel.oData.ZNonCapexDescription4,
						ZNonCapexDetails1: a1approvejsonmodel.oData.ZNonCapexDetails1,
						ZNonCapexDetails2: a1approvejsonmodel.oData.ZNonCapexDetails2,
						ZNonCapexDetails3: a1approvejsonmodel.oData.ZNonCapexDetails3,
						ZNonCapexDetails4: a1approvejsonmodel.oData.ZNonCapexDetails4,
						ZNonCapexExpense1: a1approvejsonmodel.oData.ZNonCapexExpense1,
						ZNonCapexExpense2: a1approvejsonmodel.oData.ZNonCapexExpense2,
						ZNonCapexExpense3: a1approvejsonmodel.oData.ZNonCapexExpense3,
						ZNonCapexExpense4: a1approvejsonmodel.oData.ZNonCapexExpense4,
						ZProjectDescription: a1approvejsonmodel.oData.ZProjectDescription,
						ZProjectId: a1approvejsonmodel.oData.ZProjectId,
						ZReplacingAsset: a1approvejsonmodel.oData.ZReplacingAsset,
						ZReplacingAssetCerNumber: a1approvejsonmodel.oData.ZReplacingAssetCerNumber,
						ZReplacingAssetCostCenter: a1approvejsonmodel.oData.ZReplacingAssetCostCenter,
						ZReplacingAssetDescription: a1approvejsonmodel.oData.ZReplacingAssetDescription,
						ZReplacingAssetSerialNumb: a1approvejsonmodel.oData.ZReplacingAssetSerialNumb,
						ZRequestor: a1approvejsonmodel.oData.ZRequestor,
						ZRequestorId: a1approvejsonmodel.oData.ZRequestorId,
						ZSoftware: a1approvejsonmodel.oData.ZSoftware,
						ZUsefulLifeYear: a1approvejsonmodel.oData.ZUsefulLifeYear

					};
					var a1approveurl = "/sap/opu/odata/sap/ZCER_MSS_ORJECT_SRV/";
					var a1approveodatamodel = new ODataModel(a1approveurl);

					var a1esetzcerid = "CER_MASTERSet('" + this.ZCerId + "')";

					sap.ui.core.BusyIndicator.show(0);
					a1approveodatamodel.update(a1esetzcerid, a1approvalentry, {

						success: function(odata, response) {
							sap.ui.core.BusyIndicator.hide();
							this.dpa.close();
							//	MessageToast.show("Approver1 Approved");
							master._identifyLoggedinUser(master.loggedinuser);
							HashChanger.getInstance().replaceHash("");
						}.bind(this),
						error: function(msg) {
							sap.ui.core.BusyIndicator.hide();

							MessageToast.show("Failed:2003:" + msg);

						}
					});
				} else
				if (this.zcertstatus === "6") {
					var a1approvejsonmodel6 = this.getView().getModel("objhd");

					var a1approvalentry6 = {
						ZCerId: this.ZCerId,
						ZCerStatus: "8",
						ZApprover1: a1approvejsonmodel6.oData.ZApprover1,
						ZApprover1Name: a1approvejsonmodel6.oData.ZApprover1Name,
						ZApprover2: a1approvejsonmodel6.oData.ZApprover2,
						ZApprover2Name: a1approvejsonmodel6.oData.ZApprover2Name,
						ZAssetClass: a1approvejsonmodel6.oData.ZAssetClass,
						ZBudgeted: a1approvejsonmodel6.oData.ZBudgeted,
						ZBudgetedAmount: a1approvejsonmodel6.oData.ZBudgetedAmount,
						ZBusinessJustification: a1approvejsonmodel6.oData.ZBusinessJustification,
						ZCompanyCode: a1approvejsonmodel6.oData.ZCompanyCode,
						ZCostCenter: a1approvejsonmodel6.oData.ZCostCenter,
						ZCurrency: a1approvejsonmodel6.oData.ZCurrency,
						ZDateSubmitted: a1approvejsonmodel6.oData.ZDateSubmitted,
						ZEnvironmentConsidDesc: a1approvejsonmodel6.oData.ZEnvironmentConsidDesc,
						ZEnvironmentConsideration: a1approvejsonmodel6.oData.ZEnvironmentConsideration,
						ZEstimatedFinishDate: new Date(this.byId("idfinishdate").getText()).toJSON().split("Z")[0],
						ZEstimatedStartDate: new Date(this.byId("idstartdate").getText()).toJSON().split("Z")[0],
						ZInternalResourcesDetails1: a1approvejsonmodel6.oData.ZInternalResourcesDetails1,
						ZInternalResourcesDetails2: a1approvejsonmodel6.oData.ZInternalResourcesDetails2,
						ZInternalResourcesDetails3: a1approvejsonmodel6.oData.ZInternalResourcesDetails3,
						ZInternalResourcesDetails4: a1approvejsonmodel6.oData.ZInternalResourcesDetails4,
						ZInternalResourcesGroup1: a1approvejsonmodel6.oData.ZInternalResourcesGroup1,
						ZInternalResourcesGroup2: a1approvejsonmodel6.oData.ZInternalResourcesGroup2,
						ZInternalResourcesGroup3: a1approvejsonmodel6.oData.ZInternalResourcesGroup3,
						ZInternalResourcesGroup4: a1approvejsonmodel6.oData.ZInternalResourcesGroup4,
						ZInternalResourcesHours1: a1approvejsonmodel6.oData.ZInternalResourcesHours1,
						ZInternalResourcesHours2: a1approvejsonmodel6.oData.ZInternalResourcesHours2,
						ZInternalResourcesHours3: a1approvejsonmodel6.oData.ZInternalResourcesHours3,
						ZInternalResourcesHours4: a1approvejsonmodel6.oData.ZInternalResourcesHours4,
						ZManufacturingEquipment: a1approvejsonmodel6.oData.ZManufacturingEquipment,
						ZNonCapexDescription1: a1approvejsonmodel6.oData.ZNonCapexDescription1,
						ZNonCapexDescription1Txt: a1approvejsonmodel6.oData.ZNonCapexDescription1Txt,
						ZNonCapexDescription2: a1approvejsonmodel6.oData.ZNonCapexDescription2,
						ZNonCapexDescription2Txt: a1approvejsonmodel6.oData.ZNonCapexDescription2Txt,
						ZNonCapexDescription3: a1approvejsonmodel6.oData.ZNonCapexDescription3,
						ZNonCapexDescription4: a1approvejsonmodel6.oData.ZNonCapexDescription4,
						ZNonCapexDetails1: a1approvejsonmodel6.oData.ZNonCapexDetails1,
						ZNonCapexDetails2: a1approvejsonmodel6.oData.ZNonCapexDetails2,
						ZNonCapexDetails3: a1approvejsonmodel6.oData.ZNonCapexDetails3,
						ZNonCapexDetails4: a1approvejsonmodel6.oData.ZNonCapexDetails4,
						ZNonCapexExpense1: a1approvejsonmodel6.oData.ZNonCapexExpense1,
						ZNonCapexExpense2: a1approvejsonmodel6.oData.ZNonCapexExpense2,
						ZNonCapexExpense3: a1approvejsonmodel6.oData.ZNonCapexExpense3,
						ZNonCapexExpense4: a1approvejsonmodel6.oData.ZNonCapexExpense4,
						ZProjectDescription: a1approvejsonmodel6.oData.ZProjectDescription,
						ZProjectId: a1approvejsonmodel6.oData.ZProjectId,
						ZReplacingAsset: a1approvejsonmodel6.oData.ZReplacingAsset,
						ZReplacingAssetCerNumber: a1approvejsonmodel6.oData.ZReplacingAssetCerNumber,
						ZReplacingAssetCostCenter: a1approvejsonmodel6.oData.ZReplacingAssetCostCenter,
						ZReplacingAssetDescription: a1approvejsonmodel6.oData.ZReplacingAssetDescription,
						ZReplacingAssetSerialNumb: a1approvejsonmodel6.oData.ZReplacingAssetSerialNumb,
						ZRequestor: a1approvejsonmodel6.oData.ZRequestor,
						ZRequestorId: a1approvejsonmodel6.oData.ZRequestorId,
						ZSoftware: a1approvejsonmodel6.oData.ZSoftware,
						ZUsefulLifeYear: a1approvejsonmodel6.oData.ZUsefulLifeYear

					};
					var a1approveurl6 = "/sap/opu/odata/sap/ZCER_MSS_ORJECT_SRV/";
					var a1approveodatamodel6 = new ODataModel(a1approveurl6);

					var a1esetzcerid6 = "CER_MASTERSet('" + this.ZCerId + "')";

					sap.ui.core.BusyIndicator.show(0);
					a1approveodatamodel6.update(a1esetzcerid6, a1approvalentry6, {

						success: function(odata, response) {
							this.dpa.close();
							sap.ui.core.BusyIndicator.hide();

							master._identifyLoggedinUser(master.loggedinuser);
							//	MessageToast.show("Approver1 Approved");

							HashChanger.getInstance().replaceHash("");
						}.bind(this),
						error: function(msg) {
							sap.ui.core.BusyIndicator.hide();

							MessageToast.show("Failed:2003:" + msg);

						}
					});
				}

			}

		}, // end of _onApprovalCompleted
		_onApprovalCanceled: function() {
			this.dpa.close();
		}, // end of _onCancel
		_onRejectButtonPress: function(oevent) {

			if (!this.dpr) {
				this.dpr = sap.ui.xmlfragment(this.getView().getId(), "ZCER_MANAGER.fragments.DetailsPageReject", this);
				this.getView().addDependent(this.dpr);
			}
			this.dpr.open();
			if (this.byId("rejreason").getValue() !== "") {
				this.byId("rejreason").setValue();
			}
		}, // end of _onRejectButtonPress
		_onRejectOK: function() {

			if (this.user === "FA" && this.zcertstatus === "2") {
				var rejectjsonmodel = this.getView().getModel("objhd");
				var rejectentry = {
					ZCerId: this.ZCerId,
					ZCerStatus: "3",
					ZApprover1: rejectjsonmodel.oData.ZApprover1,
					ZApprover1Name: rejectjsonmodel.oData.ZApprover1Name,
					ZApprover2: rejectjsonmodel.oData.ZApprover2,
					ZApprover2Name: rejectjsonmodel.oData.ZApprover2Name,
					ZAssetClass: rejectjsonmodel.oData.ZAssetClass,
					ZBudgeted: rejectjsonmodel.oData.ZBudgeted,
					ZBudgetedAmount: rejectjsonmodel.oData.ZBudgetedAmount,
					ZBusinessJustification: rejectjsonmodel.oData.ZBusinessJustification,
					ZCompanyCode: rejectjsonmodel.oData.ZCompanyCode,
					ZCostCenter: rejectjsonmodel.oData.ZCostCenter,
					ZCurrency: rejectjsonmodel.oData.ZCurrency,
					ZDateSubmitted: rejectjsonmodel.oData.ZDateSubmitted,
					ZEnvironmentConsidDesc: rejectjsonmodel.oData.ZEnvironmentConsidDesc,
					ZEnvironmentConsideration: rejectjsonmodel.oData.ZEnvironmentConsideration,
					ZEstimatedFinishDate: new Date(this.byId("idfinishdate").getText()).toJSON().split("Z")[0],
					ZEstimatedStartDate: new Date(this.byId("idstartdate").getText()).toJSON().split("Z")[0],
					ZInternalResourcesDetails1: rejectjsonmodel.oData.ZInternalResourcesDetails1,
					ZInternalResourcesDetails2: rejectjsonmodel.oData.ZInternalResourcesDetails2,
					ZInternalResourcesDetails3: rejectjsonmodel.oData.ZInternalResourcesDetails3,
					ZInternalResourcesDetails4: rejectjsonmodel.oData.ZInternalResourcesDetails4,
					ZInternalResourcesGroup1: rejectjsonmodel.oData.ZInternalResourcesGroup1,
					ZInternalResourcesGroup2: rejectjsonmodel.oData.ZInternalResourcesGroup2,
					ZInternalResourcesGroup3: rejectjsonmodel.oData.ZInternalResourcesGroup3,
					ZInternalResourcesGroup4: rejectjsonmodel.oData.ZInternalResourcesGroup4,
					ZInternalResourcesHours1: rejectjsonmodel.oData.ZInternalResourcesHours1,
					ZInternalResourcesHours2: rejectjsonmodel.oData.ZInternalResourcesHours2,
					ZInternalResourcesHours3: rejectjsonmodel.oData.ZInternalResourcesHours3,
					ZInternalResourcesHours4: rejectjsonmodel.oData.ZInternalResourcesHours4,
					ZManufacturingEquipment: rejectjsonmodel.oData.ZManufacturingEquipment,
					ZNonCapexDescription1: rejectjsonmodel.oData.ZNonCapexDescription1,
					ZNonCapexDescription1Txt: rejectjsonmodel.oData.ZNonCapexDescription1Txt,
					ZNonCapexDescription2: rejectjsonmodel.oData.ZNonCapexDescription2,
					ZNonCapexDescription2Txt: rejectjsonmodel.oData.ZNonCapexDescription2Txt,
					ZNonCapexDescription3: rejectjsonmodel.oData.ZNonCapexDescription3,
					ZNonCapexDescription4: rejectjsonmodel.oData.ZNonCapexDescription4,
					ZNonCapexDetails1: rejectjsonmodel.oData.ZNonCapexDetails1,
					ZNonCapexDetails2: rejectjsonmodel.oData.ZNonCapexDetails2,
					ZNonCapexDetails3: rejectjsonmodel.oData.ZNonCapexDetails3,
					ZNonCapexDetails4: rejectjsonmodel.oData.ZNonCapexDetails4,
					ZNonCapexExpense1: rejectjsonmodel.oData.ZNonCapexExpense1,
					ZNonCapexExpense2: rejectjsonmodel.oData.ZNonCapexExpense2,
					ZNonCapexExpense3: rejectjsonmodel.oData.ZNonCapexExpense3,
					ZNonCapexExpense4: rejectjsonmodel.oData.ZNonCapexExpense4,
					ZProjectDescription: rejectjsonmodel.oData.ZProjectDescription,
					ZProjectId: rejectjsonmodel.oData.ZProjectId,
					ZReplacingAsset: rejectjsonmodel.oData.ZReplacingAsset,
					ZReplacingAssetCerNumber: rejectjsonmodel.oData.ZReplacingAssetCerNumber,
					ZReplacingAssetCostCenter: rejectjsonmodel.oData.ZReplacingAssetCostCenter,
					ZReplacingAssetDescription: rejectjsonmodel.oData.ZReplacingAssetDescription,
					ZReplacingAssetSerialNumb: rejectjsonmodel.oData.ZReplacingAssetSerialNumb,
					ZRequestor: rejectjsonmodel.oData.ZRequestor,
					ZRequestorId: rejectjsonmodel.oData.ZRequestorId,
					ZSoftware: rejectjsonmodel.oData.ZSoftware,
					ZUsefulLifeYear: rejectjsonmodel.oData.ZUsefulLifeYear,
					ZReasonForReject: this.byId("rejreason").getValue()

				};
				if (this.byId("rejreason").getValue() === "" || this.byId("rejreason").getValue() === null || this.byId("rejreason").getValue() ===
					undefined) {
					MessageToast.show("Reason Mandatory");
				} else {
					var rejecturl = "/sap/opu/odata/sap/ZCER_MSS_ORJECT_SRV/";
					var rejectodatamodel = new ODataModel(rejecturl);

					var esetzcerid = "CER_MASTERSet('" + this.ZCerId + "')";
					sap.ui.core.BusyIndicator.show(0);
					rejectodatamodel.update(esetzcerid, rejectentry, {

						success: function(odata, response) {
							sap.ui.core.BusyIndicator.hide();
							this.dpr.close();
							master._identifyLoggedinUser(master.loggedinuser);
							MessageToast.show("Rejected");
							HashChanger.getInstance().replaceHash("");
						}.bind(this),
						error: function(msg) {
							sap.ui.core.BusyIndicator.hide();

							MessageToast.show("Failed:2001:" + msg);

						}
					});
				}
			} else {
				if (this.zcertstatus === "4") {

					var rejectjsonmodel4 = this.getView().getModel("objhd");
					var rejectentry4 = {
						ZCerId: this.ZCerId,
						ZCerStatus: "5",
						ZApprover1: rejectjsonmodel4.oData.ZApprover1,
						ZApprover1Name: rejectjsonmodel4.oData.ZApprover1Name,
						ZApprover2: rejectjsonmodel4.oData.ZApprover2,
						ZApprover2Name: rejectjsonmodel4.oData.ZApprover2Name,
						ZAssetClass: rejectjsonmodel4.oData.ZAssetClass,
						ZBudgeted: rejectjsonmodel4.oData.ZBudgeted,
						ZBudgetedAmount: rejectjsonmodel4.oData.ZBudgetedAmount,
						ZBusinessJustification: rejectjsonmodel4.oData.ZBusinessJustification,
						ZCompanyCode: rejectjsonmodel4.oData.ZCompanyCode,
						ZCostCenter: rejectjsonmodel4.oData.ZCostCenter,
						ZCurrency: rejectjsonmodel4.oData.ZCurrency,
						ZDateSubmitted: rejectjsonmodel4.oData.ZDateSubmitted,
						ZEnvironmentConsidDesc: rejectjsonmodel4.oData.ZEnvironmentConsidDesc,
						ZEnvironmentConsideration: rejectjsonmodel4.oData.ZEnvironmentConsideration,
						ZEstimatedFinishDate: new Date(this.byId("idfinishdate").getText()).toJSON().split("Z")[0],
						ZEstimatedStartDate: new Date(this.byId("idstartdate").getText()).toJSON().split("Z")[0],
						ZInternalResourcesDetails1: rejectjsonmodel4.oData.ZInternalResourcesDetails1,
						ZInternalResourcesDetails2: rejectjsonmodel4.oData.ZInternalResourcesDetails2,
						ZInternalResourcesDetails3: rejectjsonmodel4.oData.ZInternalResourcesDetails3,
						ZInternalResourcesDetails4: rejectjsonmodel4.oData.ZInternalResourcesDetails4,
						ZInternalResourcesGroup1: rejectjsonmodel4.oData.ZInternalResourcesGroup1,
						ZInternalResourcesGroup2: rejectjsonmodel4.oData.ZInternalResourcesGroup2,
						ZInternalResourcesGroup3: rejectjsonmodel4.oData.ZInternalResourcesGroup3,
						ZInternalResourcesGroup4: rejectjsonmodel4.oData.ZInternalResourcesGroup4,
						ZInternalResourcesHours1: rejectjsonmodel4.oData.ZInternalResourcesHours1,
						ZInternalResourcesHours2: rejectjsonmodel4.oData.ZInternalResourcesHours2,
						ZInternalResourcesHours3: rejectjsonmodel4.oData.ZInternalResourcesHours3,
						ZInternalResourcesHours4: rejectjsonmodel4.oData.ZInternalResourcesHours4,
						ZManufacturingEquipment: rejectjsonmodel4.oData.ZManufacturingEquipment,
						ZNonCapexDescription1: rejectjsonmodel4.oData.ZNonCapexDescription1,
						ZNonCapexDescription1Txt: rejectjsonmodel4.oData.ZNonCapexDescription1Txt,
						ZNonCapexDescription2: rejectjsonmodel4.oData.ZNonCapexDescription2,
						ZNonCapexDescription2Txt: rejectjsonmodel4.oData.ZNonCapexDescription2Txt,
						ZNonCapexDescription3: rejectjsonmodel4.oData.ZNonCapexDescription3,
						ZNonCapexDescription4: rejectjsonmodel4.oData.ZNonCapexDescription4,
						ZNonCapexDetails1: rejectjsonmodel4.oData.ZNonCapexDetails1,
						ZNonCapexDetails2: rejectjsonmodel4.oData.ZNonCapexDetails2,
						ZNonCapexDetails3: rejectjsonmodel4.oData.ZNonCapexDetails3,
						ZNonCapexDetails4: rejectjsonmodel4.oData.ZNonCapexDetails4,
						ZNonCapexExpense1: rejectjsonmodel4.oData.ZNonCapexExpense1,
						ZNonCapexExpense2: rejectjsonmodel4.oData.ZNonCapexExpense2,
						ZNonCapexExpense3: rejectjsonmodel4.oData.ZNonCapexExpense3,
						ZNonCapexExpense4: rejectjsonmodel4.oData.ZNonCapexExpense4,
						ZProjectDescription: rejectjsonmodel4.oData.ZProjectDescription,
						ZProjectId: rejectjsonmodel4.oData.ZProjectId,
						ZReplacingAsset: rejectjsonmodel4.oData.ZReplacingAsset,
						ZReplacingAssetCerNumber: rejectjsonmodel4.oData.ZReplacingAssetCerNumber,
						ZReplacingAssetCostCenter: rejectjsonmodel4.oData.ZReplacingAssetCostCenter,
						ZReplacingAssetDescription: rejectjsonmodel4.oData.ZReplacingAssetDescription,
						ZReplacingAssetSerialNumb: rejectjsonmodel4.oData.ZReplacingAssetSerialNumb,
						ZRequestor: rejectjsonmodel4.oData.ZRequestor,
						ZRequestorId: rejectjsonmodel4.oData.ZRequestorId,
						ZSoftware: rejectjsonmodel4.oData.ZSoftware,
						ZUsefulLifeYear: rejectjsonmodel4.oData.ZUsefulLifeYear,
						ZReasonForReject: this.byId("rejreason").getValue()

					};
					if (this.byId("rejreason").getValue() === "" || this.byId("rejreason").getValue() === null || this.byId("rejreason").getValue() ===
						undefined) {
						MessageToast.show("Reason Mandatory");
					} else {
						var rejecturl4 = "/sap/opu/odata/sap/ZCER_MSS_ORJECT_SRV/";
						var rejectodatamodel4 = new ODataModel(rejecturl4);

						var esetzcerid4 = "CER_MASTERSet('" + this.ZCerId + "')";
						sap.ui.core.BusyIndicator.show(0);
						rejectodatamodel4.update(esetzcerid4, rejectentry4, {

							success: function(odata, response) {
								sap.ui.core.BusyIndicator.hide();
								this.dpr.close();
								master._identifyLoggedinUser(master.loggedinuser);
								MessageToast.show("Rejected");
								HashChanger.getInstance().replaceHash("");
							}.bind(this),
							error: function(msg) {
								sap.ui.core.BusyIndicator.hide();

								MessageToast.show("Failed:2001:" + msg);

							}
						});
					}

				} else
				if (this.zcertstatus === "6") {

					var rejectjsonmodel6 = this.getView().getModel("objhd");
					var rejectentry6 = {
						ZCerId: this.ZCerId,
						ZCerStatus: "7",
						ZApprover1: rejectjsonmodel6.oData.ZApprover1,
						ZApprover1Name: rejectjsonmodel6.oData.ZApprover1Name,
						ZApprover2: rejectjsonmodel6.oData.ZApprover2,
						ZApprover2Name: rejectjsonmodel6.oData.ZApprover2Name,
						ZAssetClass: rejectjsonmodel6.oData.ZAssetClass,
						ZBudgeted: rejectjsonmodel6.oData.ZBudgeted,
						ZBudgetedAmount: rejectjsonmodel6.oData.ZBudgetedAmount,
						ZBusinessJustification: rejectjsonmodel6.oData.ZBusinessJustification,
						ZCompanyCode: rejectjsonmodel6.oData.ZCompanyCode,
						ZCostCenter: rejectjsonmodel6.oData.ZCostCenter,
						ZCurrency: rejectjsonmodel6.oData.ZCurrency,
						ZDateSubmitted: rejectjsonmodel6.oData.ZDateSubmitted,
						ZEnvironmentConsidDesc: rejectjsonmodel6.oData.ZEnvironmentConsidDesc,
						ZEnvironmentConsideration: rejectjsonmodel6.oData.ZEnvironmentConsideration,
						ZEstimatedFinishDate: new Date(this.byId("idfinishdate").getText()).toJSON().split("Z")[0],
						ZEstimatedStartDate: new Date(this.byId("idstartdate").getText()).toJSON().split("Z")[0],
						ZInternalResourcesDetails1: rejectjsonmodel6.oData.ZInternalResourcesDetails1,
						ZInternalResourcesDetails2: rejectjsonmodel6.oData.ZInternalResourcesDetails2,
						ZInternalResourcesDetails3: rejectjsonmodel6.oData.ZInternalResourcesDetails3,
						ZInternalResourcesDetails4: rejectjsonmodel6.oData.ZInternalResourcesDetails4,
						ZInternalResourcesGroup1: rejectjsonmodel6.oData.ZInternalResourcesGroup1,
						ZInternalResourcesGroup2: rejectjsonmodel6.oData.ZInternalResourcesGroup2,
						ZInternalResourcesGroup3: rejectjsonmodel6.oData.ZInternalResourcesGroup3,
						ZInternalResourcesGroup4: rejectjsonmodel6.oData.ZInternalResourcesGroup4,
						ZInternalResourcesHours1: rejectjsonmodel6.oData.ZInternalResourcesHours1,
						ZInternalResourcesHours2: rejectjsonmodel6.oData.ZInternalResourcesHours2,
						ZInternalResourcesHours3: rejectjsonmodel6.oData.ZInternalResourcesHours3,
						ZInternalResourcesHours4: rejectjsonmodel6.oData.ZInternalResourcesHours4,
						ZManufacturingEquipment: rejectjsonmodel6.oData.ZManufacturingEquipment,
						ZNonCapexDescription1: rejectjsonmodel6.oData.ZNonCapexDescription1,
						ZNonCapexDescription1Txt: rejectjsonmodel6.oData.ZNonCapexDescription1Txt,
						ZNonCapexDescription2: rejectjsonmodel6.oData.ZNonCapexDescription2,
						ZNonCapexDescription2Txt: rejectjsonmodel6.oData.ZNonCapexDescription2Txt,
						ZNonCapexDescription3: rejectjsonmodel6.oData.ZNonCapexDescription3,
						ZNonCapexDescription4: rejectjsonmodel6.oData.ZNonCapexDescription4,
						ZNonCapexDetails1: rejectjsonmodel6.oData.ZNonCapexDetails1,
						ZNonCapexDetails2: rejectjsonmodel6.oData.ZNonCapexDetails2,
						ZNonCapexDetails3: rejectjsonmodel6.oData.ZNonCapexDetails3,
						ZNonCapexDetails4: rejectjsonmodel6.oData.ZNonCapexDetails4,
						ZNonCapexExpense1: rejectjsonmodel6.oData.ZNonCapexExpense1,
						ZNonCapexExpense2: rejectjsonmodel6.oData.ZNonCapexExpense2,
						ZNonCapexExpense3: rejectjsonmodel6.oData.ZNonCapexExpense3,
						ZNonCapexExpense4: rejectjsonmodel6.oData.ZNonCapexExpense4,
						ZProjectDescription: rejectjsonmodel6.oData.ZProjectDescription,
						ZProjectId: rejectjsonmodel6.oData.ZProjectId,
						ZReplacingAsset: rejectjsonmodel6.oData.ZReplacingAsset,
						ZReplacingAssetCerNumber: rejectjsonmodel6.oData.ZReplacingAssetCerNumber,
						ZReplacingAssetCostCenter: rejectjsonmodel6.oData.ZReplacingAssetCostCenter,
						ZReplacingAssetDescription: rejectjsonmodel6.oData.ZReplacingAssetDescription,
						ZReplacingAssetSerialNumb: rejectjsonmodel6.oData.ZReplacingAssetSerialNumb,
						ZRequestor: rejectjsonmodel6.oData.ZRequestor,
						ZRequestorId: rejectjsonmodel6.oData.ZRequestorId,
						ZSoftware: rejectjsonmodel6.oData.ZSoftware,
						ZUsefulLifeYear: rejectjsonmodel6.oData.ZUsefulLifeYear,
						ZReasonForReject: this.byId("rejreason").getValue()

					};
					if (this.byId("rejreason").getValue() === "" || this.byId("rejreason").getValue() === null || this.byId("rejreason").getValue() ===
						undefined) {
						MessageToast.show("Reason Mandatory");
					} else {
						var rejecturl6 = "/sap/opu/odata/sap/ZCER_MSS_ORJECT_SRV/";
						var rejectodatamodel6 = new ODataModel(rejecturl6);

						var esetzcerid6 = "CER_MASTERSet('" + this.ZCerId + "')";
						sap.ui.core.BusyIndicator.show(0);
						rejectodatamodel6.update(esetzcerid6, rejectentry6, {

							success: function(odata, response) {
								sap.ui.core.BusyIndicator.hide();
								this.dpr.close();
								master._identifyLoggedinUser(master.loggedinuser);
								MessageToast.show("Rejected");
								HashChanger.getInstance().replaceHash("");
							}.bind(this),
							error: function(msg) {
								sap.ui.core.BusyIndicator.hide();

								MessageToast.show("Failed:2001:" + msg);

							}
						});
					}

				}

			}

		}, // end of _onRejectOK
		_onRejectCancel: function() {
			this.dpr.close();
		}, //end of _onRejectCancel
		onInit: function() {

			var loggedinuser = "/sap/opu/odata/sap/ZCER_PROJECT_SRV/";
			var globalodatamodel = new ODataModel(loggedinuser);
			sap.ui.core.BusyIndicator.show(0);
			globalodatamodel.read("/CER_USERSet('US')", {
				success: function(odata, resp) {
					sap.ui.core.BusyIndicator.hide();
					this._identifyLoggedinUser(odata.UserName);
				}.bind(this),
				error: function(msg) {

					MessageToast.show("Failed:" + msg);
					sap.ui.core.BusyIndicator.hide();
				}
			});
			this.oRouter = sap.ui.core.UIComponent.getRouterFor(this);

			this.oRouter.getRoute("1460972029486_S1").attachPatternMatched(this._handleZCerIdMatched, this);

		}, // end of onInit

		but2input1: function() {
			this.byId("idinapp1").setValue();
			this.byId("butapp1").setVisible(false);
			this.byId("idinapp1").setVisible(true);
			this.byId("idbutapp1").setVisible(true);
			this.byId("idbutappdec1").setVisible(true);

		}, // end of but2input
		input2but1: function() {

			var appr1 = this.byId("idinapp1").getValue();
		//	var appr2 = this.byId("idinapp2").getValue();
			var apprlink = "/sap/opu/odata/sap/ZCER_MSS_ORJECT_SRV/";
			var approdata = new ODataModel(apprlink);

			var changeApprList = {
				ZCerId	  : this.ZCerId,
				ZApprover1: appr1
			};
			//	var eset = "/CER_MASTERSet(ZCerId='"+ZCerId+"',ZApprover1='"+appr1+"',ZApprover2='"+appr2+"')";
			var esetzcerid = "CER_MASTERSet('" + this.ZCerId + "')";
			approdata.update(esetzcerid, changeApprList, {
				success: function(odata, resp) {
					master._identifyLoggedinUser(master.loggedinuser);
					//this.byId("app1name").setText(appr1);

					this.byId("butapp1").setVisible(true);
					this.byId("idinapp1").setVisible(false);
					this.byId("idbutapp1").setVisible(false);
					this.byId("idbutappdec1").setVisible(false);
					var details_url = "/sap/opu/odata/sap/ZCER_MSS_ORJECT_SRV/";
					var details_odatamodel = new ODataModel(details_url);

					var esetzcerid1 = "CER_MASTERSet('" + this.ZCerId + "')";
					sap.ui.core.BusyIndicator.show(0);
					details_odatamodel.read(esetzcerid1, {

						success: function(odata, response) {
							sap.ui.core.BusyIndicator.hide();
							this.byId("app1name").setText(odata.ZApprover1Name);

						}.bind(this),
						error: function(msg) {
							sap.ui.core.BusyIndicator.hide();
							MessageToast.show("Failed:2011:" + msg);

						}
					});

				}.bind(this),
				error: function(msg) {
					MessageToast.show("No User with the ID, please check");
				}
			});
		}, // end of input2but1
		but2input2: function() {
			this.byId("idinapp2").setValue();
			this.byId("butapp2").setVisible(false);
			this.byId("idinapp2").setVisible(true);
			this.byId("idbutapp2").setVisible(true);
			this.byId("idbutappdec2").setVisible(true);

		}, // end of but2input2
		input2but2: function() {

		//	var appr1 = this.byId("idinapp1").getValue();
			var appr2 = this.byId("idinapp2").getValue();
			var apprlink = "/sap/opu/odata/sap/ZCER_MSS_ORJECT_SRV/";
			var approdata = new ODataModel(apprlink);

			var esetzcerid = "CER_MASTERSet('" + this.ZCerId + "')";
			var changeApprList = {

					ZCerId	  : this.ZCerId,
				ZApprover2: appr2
			};
			approdata.update(esetzcerid, changeApprList, {
				success: function(odata, resp) {

					master._identifyLoggedinUser(master.loggedinuser);
					this.byId("butapp2").setVisible(true);
					this.byId("idinapp2").setVisible(false);
					this.byId("idbutapp2").setVisible(false);
					this.byId("idbutappdec2").setVisible(false);
					var details_url = "/sap/opu/odata/sap/ZCER_MSS_ORJECT_SRV/";
					var details_odatamodel = new ODataModel(details_url);

					var esetzcerid1 = "CER_MASTERSet('" + this.ZCerId + "')";
					sap.ui.core.BusyIndicator.show(0);
					details_odatamodel.read(esetzcerid1, {

						success: function(odata, response) {
							sap.ui.core.BusyIndicator.hide();
							this.byId("app2name").setText(odata.ZApprover2Name);
							//this.byId("app1name").setText(odata.ZApprover1Name);

						}.bind(this),
						error: function(msg) {
							sap.ui.core.BusyIndicator.hide();
							MessageToast.show("Failed:2012:" + msg);

						}
					});
				}.bind(this),
				error: function(msg) {
					MessageToast.show("No User with the ID, please check");
				}
			});
		}, // end of input2but2
		_toupper1 : function(oevent){
			oevent.getSource().setValue(oevent.getSource().getValue().toUpperCase());
		}, // end of _toupper1
		_toupper2 : function(oevent){
			oevent.getSource().setValue(oevent.getSource().getValue().toUpperCase());
		}, // end of _toupper2
		input2but1cancel: function(oevent) {
			this.byId("butapp1").setVisible(true);
			this.byId("idinapp1").setVisible(false);
			this.byId("idbutapp1").setVisible(false);
			this.byId("idbutappdec1").setVisible(false);
		}, // end of input2but1cancel
		input2but2cancel: function(oevent) {
				this.byId("butapp2").setVisible(true);
				this.byId("idinapp2").setVisible(false);
				this.byId("idbutapp2").setVisible(false);
				this.byId("idbutappdec2").setVisible(false);
			} // end of input2but2cancel

	});
}, /* bExport= */ true);