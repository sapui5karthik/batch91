sap.ui.define([
	] , function () {
		"use strict";

		return {


			width1 :function(w1){
			if(!w1){
				return "";
			}
			if(w1 === "0.000"){
				return "NO WIDTH";
			}
			return parseFloat(w1).toFixed(6);
			},
			discprice1 : function(dp1){
				if(dp1 >= 30 && dp1 <= 50){
					return parseFloat(dp1 - 10).toFixed(2);
				}
				if(dp1 >= 50 && dp1 <= 100){
					return dp1 - 20.00;
				}
				if(dp1 > 100){
					return dp1 - 30.00;
				}
				
				return dp1;
			},
			pricecolor1 : function(pcolor){
				if(pcolor >= 30 && pcolor <= 50){
					return 'Success';
				}
				if(pcolor >= 50 && pcolor <= 100){
					return 'Warning';
				}
				if(pcolor > 100){
					return 'Error';
				}
				
				return 'None';
			},
			/**
			 * Rounds the number unit value to 2 digits
			 * @public
			 * @param {string} sValue the number string to be rounded
			 * @returns {string} sValue with 2 digits rounded
			 */
			numberUnit : function (sValue) {
				if (!sValue) {
					return "";
				}
				return parseFloat(sValue).toFixed(2);
			}

		};

	}
);