sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/odata/ODataModel",
	"sap/ui/model/json/JSONModel",
	"sap/m/MessageToast"
], function(Controller,ODataModel,JSONModel,MessageToast) {
	"use strict";

	return Controller.extend("zproj04sapprodZSAPUI5_Proj04_SAPProducts.controller.SapProduct", {
	
	onInit : function(){
		//defaults
		
		this.byId("productspanel").setExpanded(true);
		
		
		
		var data = "/sap/opu/odata/iwbep/GWSAMPLE_BASIC/";
		var odatamodel = new ODataModel(data);
		var jsonmodel = new JSONModel();
		var otable = this.byId("sapproductstable");
		
		
		//otable.setBusy(true);
		sap.ui.core.BusyIndicator.show(0);
		odatamodel.read("/ProductSet",{
			
			success : function(req,resp){
			//	otable.setBusy(false);
			sap.ui.core.BusyIndicator.hide();
				
				jsonmodel.setSizeLimit(1000);
				jsonmodel.setData(req.results);
				this.getView().byId("sapproductstable").setModel(jsonmodel,"sapprod");
					this.getView().byId("sapproductsclienttable").setModel(jsonmodel,"sapprodclient");
			}.bind(this),
			error : function(msg){ 
				//	otable.setBusy(false);
				sap.ui.core.BusyIndicator.hide();
				MessageToast.show("Failed:1000:" + msg);
			}
			
			
		});
		
	
		
		
	}
	});
});