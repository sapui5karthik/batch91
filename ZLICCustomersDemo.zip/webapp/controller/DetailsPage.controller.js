sap.ui.define([
	"sap/ui/core/mvc/Controller"
], function(Controller) {
	"use strict";

	return Controller.extend("zliccustomersdemo.ZLICCustomersDemo.controller.DetailsPage", {

		/**
		 * Called when a controller is instantiated and its View controls (if available) are already created.
		 * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
		 * @memberOf zliccustomersdemo.ZLICCustomersDemo.view.DetailsPage
		 */
		onInit: function() {
			this.oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			this.oRouter.getRoute("detailpage").attachPatternMatched(this.customerdata, this);
		},
		customerdata: function(oevent) {
			var ID = oevent.getParameter("arguments").ID;
			var customername = oevent.getParameter("arguments").customername;
			var totalpremamntandterm = oevent.getParameter("arguments").totalpremamntandterm;
			var premiumbegda = oevent.getParameter("arguments").premiumbegda;
			var emiamnttobepaidonduedate = oevent.getParameter("arguments").emiamnttobepaidonduedate;
			var amntpaidtillnow = oevent.getParameter("arguments").amntpaidtillnow;
			var pendingamnttobepaid = oevent.getParameter("arguments").pendingamnttobepaid;
			var monthlypay = oevent.getParameter("arguments").monthlypay;
			var yearlypay = oevent.getParameter("arguments").yearlypay;
			var premiumenda = oevent.getParameter("arguments").premiumenda;
			
			this.byId("SimpleFormChange354").setTitle("Customer Details of " + customername);
			this.byId("ID").setText(ID);
			this.byId("customername").setText(customername);
			this.byId("totalpremamntandterm").setText(totalpremamntandterm);
			this.byId("premiumbegda").setText(premiumbegda);
			this.byId("emiamnttobepaidonduedate").setText(emiamnttobepaidonduedate);
			this.byId("amntpaidtillnow").setText(amntpaidtillnow);
			this.byId("pendingamnttobepaid").setText(pendingamnttobepaid);
			this.byId("monthlypay").setText(monthlypay);
			this.byId("yearlypay").setText(yearlypay);
			this.byId("premiumenda").setText(premiumenda);
		},
		_backtoobject: function() {
			this.oRouter.navTo("object", {}, true);
		},
		_logout : function(oevent){
			this.oRouter.navTo("worklist",{},true);
		},// end of _logout

		/**
		 * Similar to onAfterRendering, but this hook is invoked before the controller's View is re-rendered
		 * (NOT before the first rendering! onInit() is used for that one!).
		 * @memberOf zliccustomersdemo.ZLICCustomersDemo.view.DetailsPage
		 */
		//	onBeforeRendering: function() {
		//
		//	},

		/**
		 * Called when the View has been rendered (so its HTML is part of the document). Post-rendering manipulations of the HTML could be done here.
		 * This hook is the same one that SAPUI5 controls get after being rendered.
		 * @memberOf zliccustomersdemo.ZLICCustomersDemo.view.DetailsPage
		 */
		//	onAfterRendering: function() {
		//
		//	},

		/**
		 * Called when the Controller is destroyed. Use this one to free resources and finalize activities.
		 * @memberOf zliccustomersdemo.ZLICCustomersDemo.view.DetailsPage
		 */
		//	onExit: function() {
		//
		//	}

	});

});