sap.ui.define(["sap/ui/core/mvc/Controller",
	"sap/m/MessageBox",
	"./ReportDialog",
	"./utilities",
	"sap/ui/core/routing/History",
	"ZCER_MANAGER/model/formatter",
	"sap/ui/model/odata/ODataModel",
	"sap/ui/model/json/JSONModel",
	"sap/ui/model/Filter",
	"sap/m/MessageToast",
	"sap/ui/model/FilterOperator",
		'sap/ui/core/util/Export',
	'sap/ui/core/util/ExportTypeCSV',
		"sap/ui/core/format/DateFormat"
], function(BaseController, MessageBox, ReportDialog, Utilities, History, formatter, ODataModel, JSONModel, Filter, MessageToast,
	FilterOperator,Export,ExportTypeCSV,DateFormat) {
	"use strict";

	return BaseController.extend("ZCER_MANAGER.controller.MainPage", {
		formatter: formatter,
		_identifyLoggedinUser: function(user) {
			this.loggedinuser = user;

			// check if logged in user is Finance Approver

			var data_loggeduser = "/sap/opu/odata/sap/ZCER_PROJECT_SRV/";

			var datamodel_loggedinuser = new ODataModel(data_loggeduser);
			var finteam = new Filter("DropDown", FilterOperator.EQ, "Z_CER_FIN_TEAM");

			datamodel_loggedinuser.read("/CER_DROP_DOWNSet", {
				filters: [finteam],
				success: function(odata, response) {
					var a = [];
					for (var i = 0; i < odata.results.length; ++i) {

						if (this.loggedinuser === odata.results[i].DispValue) {
							a.push(this.loggedinuser);
						}
					}

					if (a.length !== 0) {
					//	MessageToast.show("Finance Approver");
						var master_odata_url = "/sap/opu/odata/sap/ZCER_MSS_ORJECT_SRV/";
						var masterodata = new ODataModel(master_odata_url);
						var masterjson = new JSONModel();
						var filterstatus2 = new Filter("ZCerStatus", FilterOperator.EQ, "2");
						var filterstatus4 = new Filter("ZCerStatus", FilterOperator.EQ, "4");
						var filterstatus6 = new Filter("ZCerStatus", FilterOperator.EQ, "6");
						sap.ui.core.BusyIndicator.show(0);
						masterodata.read("/CER_MASTERSet", {
							filters: [new Filter([filterstatus2, filterstatus4, filterstatus6], false)],
							success: function(odata1, response1) {
								sap.ui.core.BusyIndicator.hide();
								masterjson.setData(odata1.results);
								//this.byId("masterlist").getItems()[0].selected;
								this.getView().byId("masterlist").setModel(masterjson, "submitcer");
							}.bind(this),
							error: function(msg1) {
								sap.ui.core.BusyIndicator.hide();
								MessageToast.show("Failed:3000:" + msg1);
							}

						});

					} else {
					//	MessageToast.show("Not Finance Approver");
						var master_odata_url1 = "/sap/opu/odata/sap/ZCER_MSS_ORJECT_SRV/";
						var masterodata1 = new ODataModel(master_odata_url1);
						var masterjson1 = new JSONModel();

						var filterstatus4_1 = new Filter("ZCerStatus", FilterOperator.EQ, "4");
						var filterstatus6_1 = new Filter("ZCerStatus", FilterOperator.EQ, "6");
						sap.ui.core.BusyIndicator.show(0);
						masterodata1.read("/CER_MASTERSet", {
							filters: [new Filter([filterstatus4_1, filterstatus6_1], false)],
							success: function(odata2, response2) {
								sap.ui.core.BusyIndicator.hide();
								masterjson1.setData(odata2.results);

								this.getView().byId("masterlist").setModel(masterjson1, "submitcer");
							}.bind(this),
							error: function(msg2) {
								sap.ui.core.BusyIndicator.hide();
								MessageToast.show("Failed:3001:" + msg2);
							}

						});

					}

				}.bind(this),
				error: function(msg) {
					MessageToast.show("Failed:0001" + msg);
				}
			});

		},
		onInit: function() {
			sap.ui.core.BusyIndicator.show(0);
				// UI5 Developer: Suman Venkatapuram
			// OData Developer: Grishmaben Patel
			
				window.master = this;
			// this.oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			// this.oRouter.getTarget("MainPage").attachDisplay(jQuery.proxy(this.handleRouteMatched, this));
			var loggedinuser = "/sap/opu/odata/sap/ZCER_PROJECT_SRV/";
			var globalodatamodel = new ODataModel(loggedinuser);

			
			globalodatamodel.read("/CER_USERSet('US')", {
				success: function(odata, resp) {
					sap.ui.core.BusyIndicator.hide();
					this._identifyLoggedinUser(odata.UserName);
				}.bind(this),
				error: function(msg) {
					sap.ui.core.BusyIndicator.hide();
					MessageToast.show("Failed:" + msg);
				}
			});
		}, // end of onInit
	
		
		handleRouteMatched: function(oEvent) {
			var sAppId = "App5f7cfa4ad5dbc32eadbb26ae";

			var oParams = {};
			var oView = this.getView();
			var bSelectFirstListItem = true;
			if (oEvent.mParameters.data.context || oEvent.mParameters.data.masterContext) {
				this.sContext = oEvent.mParameters.data.context;

				this.sMasterContext = oEvent.mParameters.data.masterContext;

			} else {
				if (this.getOwnerComponent().getComponentData()) {
					var patternConvert = function(oParam) {
						if (Object.keys(oParam).length !== 0) {
							for (var prop in oParam) {
								if (prop !== "sourcePrototype" && prop.includes("Set")) {
									return prop + "(" + oParam[prop][0] + ")";
								}
							}
						}
					};

					this.sMasterContext = patternConvert(this.getOwnerComponent().getComponentData().startupParameters);

				}
			}

			var oPath;

			if (this.sMasterContext && oEvent.getParameters().config.bypassed.target[0] !== this.sMasterContext) {
				oPath = {
					path: "/" + this.sMasterContext,
					parameters: oParams
				};
				this.getView().bindObject(oPath);
			} else if (this.sContext) {
				var sCurrentContextPath = "/" + this.sContext;

				bSelectFirstListItem = false;
			}

			if (bSelectFirstListItem) {
				oView.addEventDelegate({
					onBeforeShow: function() {
						var oContent = this.getView().getContent();
						if (oContent) {
							if (!sap.ui.Device.system.phone) {
								var oList = oContent[0].getContent() ? oContent[0].getContent()[0] : undefined;
								if (oList) {
									var sContentName = oList.getMetadata().getName();
									if (sContentName.indexOf("List") > -1) {
										oList.attachEventOnce("updateFinished", function() {
											var oFirstListItem = this.getItems()[0];
											if (oFirstListItem) {
												oList.setSelectedItem(oFirstListItem);
												oList.fireItemPress({
													listItem: oFirstListItem
												});
											}
										}.bind(oList));
									}
								}
							}
						}
					}.bind(this)
				});
			}

		},
	/*	_attachSelectListItemWithContextPath: function(sContextPath) {
			var oView = this.getView();
			var oContent = this.getView().getContent();
			if (oContent) {
				if (!sap.ui.Device.system.phone) {
					var oList = oContent[0].getContent() ? oContent[0].getContent()[0] : undefined;
					if (oList && sContextPath) {
						var sContentName = oList.getMetadata().getName();
						var oItemToSelect, oItem, oContext, aItems, i;
						if (sContentName.indexOf("List") > -1) {
							if (oList.getItems().length) {
								oItemToSelect = null;
								aItems = oList.getItems();
								for (i = 0; i < aItems.length; i++) {
									oItem = aItems[i];
									oContext = oItem.getBindingContext();
									if (oContext && oContext.getPath() === sContextPath) {
										oItemToSelect = oItem;
									}
								}
								if (oItemToSelect) {
									oList.setSelectedItem(oItemToSelect);
								}
							} else {
								oView.addEventDelegate({
									onBeforeShow: function() {
										oList.attachEventOnce("updateFinished", function() {
											oItemToSelect = null;
											aItems = oList.getItems();
											for (i = 0; i < aItems.length; i++) {
												oItem = aItems[i];
												oContext = oItem.getBindingContext();
												if (oContext && oContext.getPath() === sContextPath) {
													oItemToSelect = oItem;
												}
											}
											if (oItemToSelect) {
												oList.setSelectedItem(oItemToSelect);
											}
										});
									}
								});
							}
						}

					}
				}
			}

		},*/
		_onPageNavButtonPress: function() {
			var oHistory = History.getInstance();
			var sPreviousHash = oHistory.getPreviousHash();
			var oQueryParams = this.getQueryParameters(window.location);

			if (sPreviousHash !== undefined || oQueryParams.navBackToLaunchpad) {
				window.history.go(-1);
			} else {
				var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
				oRouter.navTo("default", true);
			}

		},
	/*	getQueryParameters: function(oLocation) {
			var oQuery = {};
			var aParams = oLocation.search.substring(1).split("&");
			for (var i = 0; i < aParams.length; i++) {
				var aPair = aParams[i].split("=");
				oQuery[aPair[0]] = decodeURIComponent(aPair[1]);
			}
			return oQuery;

		},*/
		_onObjectListItemPress: function(oevent) {

			//	var oBindingContext = oevent.getSource().getBindingContext("submitcer");
			var projid = oevent.getParameter("listItem").getIntro();

			this.oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			this.oRouter.navTo("1460972029486_S1", {
				ZCerId: projid,
				from: "MainPage",
				to: "1460972029486_S1"
			}, true);

			/*return new Promise(function(fnResolve) {

				this.doNavigate("1460972029486_S1", oBindingContext, fnResolve, "");
			}.bind(this)).catch(function(err) {
				if (err !== undefined) {
					MessageBox.error(err.message);
				}
			});*/

		},
		/*doNavigate: function(sRouteName, oBindingContext, fnPromiseResolve, sViaRelation) {
			var sPath = (oBindingContext) ? oBindingContext.getPath() : null;
			var oModel = (oBindingContext) ? oBindingContext.getModel() : null;

			var sEntityNameSet;
			if (sPath !== null && sPath !== "") {
				if (sPath.substring(0, 1) === "/") {
					sPath = sPath.substring(1);
				}
				sEntityNameSet = sPath.split("(")[0];
			}
			var sNavigationPropertyName;
			var sMasterContext = this.sMasterContext ? this.sMasterContext : sPath;

			if (sEntityNameSet !== null) {
				sNavigationPropertyName = sViaRelation || this.getOwnerComponent().getNavigationPropertyForNavigationWithContext(sEntityNameSet,
					sRouteName);
			}
			if (sNavigationPropertyName !== null && sNavigationPropertyName !== undefined) {
				if (sNavigationPropertyName === "") {
					this.oRouter.navTo(sRouteName, {
						context: sPath,
						masterContext: sMasterContext
					}, false);
				} else {
					oModel.createBindingContext(sNavigationPropertyName, oBindingContext, null, function(bindingContext) {
						if (bindingContext) {
							sPath = bindingContext.getPath();
							if (sPath.substring(0, 1) === "/") {
								sPath = sPath.substring(1);
							}
						} else {
							sPath = "undefined";
						}

						// If the navigation is a 1-n, sPath would be "undefined" as this is not supported in Build
						if (sPath === "undefined") {
							this.oRouter.navTo(sRouteName);
						} else {
							this.oRouter.navTo(sRouteName, {
								context: sPath,
								masterContext: sMasterContext
							}, false);
						}
					}.bind(this));
				}
			} else {
				this.oRouter.navTo(sRouteName);
			}

			if (typeof fnPromiseResolve === "function") {
				fnPromiseResolve();
			}

		},*/
		_pastCERs : function(){
			
			var data_cerstatus = "/sap/opu/odata/sap/ZCER_PROJECT_SRV/";
			var datamodel_opencer = new ODataModel(data_cerstatus);
			var jsonmodel_opencer = new JSONModel();

			var filteropencerstatus4 = new Filter("ZCerStatus", FilterOperator.EQ, "4");
			var filteropencerstatus6 = new Filter("ZCerStatus", FilterOperator.EQ, "6");
			var filteropencerstatus8 = new Filter("ZCerStatus", FilterOperator.EQ, "8");
			var filtery = new Filter("ZBudgeted",FilterOperator.EQ,"Y");
			

			datamodel_opencer.read("/CER_MASTERSet", {
				filters: [new Filter([filteropencerstatus4, filteropencerstatus6, filteropencerstatus8,filtery], false)],
				success: function(odata, response) {
					jsonmodel_opencer.setData(odata.results);
					this.getView().setModel(jsonmodel_opencer);

					var oExport = new Export({

						// Type that will be used to generate the content. Own ExportType's can be created to support other formats
						exportType: new ExportTypeCSV({
							separatorChar: "\t",

							mimeType: "application/vnd.ms-excel",

							charset: "utf-8",

							fileExtension: "xls"
						}),
						// Pass in the model created above

						//	models : this.getView().getModel(),
						//models: this.getView().byId("table_opencerexport").oModels.opencers,
						models: this.getView().getModel(),
						// binding information for the rows aggregation
						rows: {
							path: "/"
						},
						// column definitions with column name and binding info for the content

						columns: [{
								name: "Company",
								template: {
									content: "{ZCompanyCode}"
								}
							}, {
								name: "Submit with Budget",
								template: {
									content: "{ZBudgeted}"
								}
							}, {
								name: "Cost Center",
								template: {
									content: "{ZCostCenter}"
								}
							}, {
								name: "Project",
								template: {
									content: "{ZProjectId}"
								}
							}, {
								name: "Project Description",
								template: {
									content: "{ZProjectDescription}"
								}

							}, {
								name: "Est.Start Date",
								template: {
									content: {
										parts: ["ZEstimatedStartDate"],
										formatter: function(date) {

											if (date !== undefined) {

												var oDateFormat = DateFormat.getDateInstance({
													scale: "medium",
													pattern: "dd-MMM-yyyy"

												});
												var subFromDate = oDateFormat.format(new Date(date));

												return subFromDate;
											} else {
												return "";
											}

										}
									}

								}
							}, {
								name: "Est.Finish Date",
								template: {
									content: {
										parts: ["ZEstimatedFinishDate"],
										formatter: function(date) {

											if (date !== undefined) {

												var oDateFormat = DateFormat.getDateInstance({
													scale: "medium",
													pattern: "dd-MMM-yyyy"

												});
												var subFromDate = oDateFormat.format(new Date(date));

												return subFromDate;
											} else {
												return "";
											}

										}
									}

								}

							},

							{
								name: "Asset Class/Category",
								template: {
									content: "{ZAssetClass}"
								}
							}, {
								name: "Usefull Life",
								template: {
									content: "{ZUsefulLifeYear}"
								}
							}, {
								name: "ManufacturingEquipment",
								template: {
									content: "{ZManufacturingEquipment}"
								}
							}, {
								name: "Software",
								template: {
									content: "{ZSoftware}"
								}
							}, {
								name: "Requestor",
								template: {
									content: "{ZRequestor}"
								}
							}, {
								name: "Approver1",
								template: {
									content: "{ZApprover1Name}"
								}
							}, {
								name: "Approver2",
								template: {
									content: "{ZApprover2Name}"
								}
							}

							/*	{
									name: "Status",
									template: {
										content: {
											parts: ["ZCerStatus"],
											formatter: function(cs) {
												if (cs === "1") {
													return "Draft";
												}
												if (cs === "2") {
													return "Submitted";
												}
												if (cs === "4") {
													return "Finance Approved";
												}
												if (cs === "6") {
													return "Approver1 Approved";
												}
											}
										}

									}
								}*/

						]
					});

					// download exported file
					oExport.saveFile().catch(function(oError) {
						MessageBox.error("Error when downloading data. Please try again!\n\n" + oError);
					}).then(function() {
						oExport.destroy();
					});
				}.bind(this),
				error: function(msg) {

					MessageToast.show("Failed:2000:" + msg);

				}
			});

		
		},
		_onButtonPress: function(oEvent) {

			var sDialogName = "ReportDialog";
			this.mDialogs = this.mDialogs || {};
			var oDialog = this.mDialogs[sDialogName];
			if (!oDialog) {
				oDialog = new ReportDialog(this.getView());
				this.mDialogs[sDialogName] = oDialog;

				// For navigation.
				oDialog.setRouter(this.oRouter);
			}

			var context = oEvent.getSource().getBindingContext();
			oDialog._oControl.setBindingContext(context);

			oDialog.open();

		}

	});
}, /* bExport= */ true);